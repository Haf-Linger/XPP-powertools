#!/etc/xyvision/common/perl/bin/perl
#xychange perl transformation template
# V1.00 - 30-08-2019 - initial version 
my $Version = "1.00";

use strict;
use warnings;
use 5.028;

use File::Basename;
use Path::Tiny;
#=============================================================
#  RegEx PATTERNS
#=============================================================
my $tagP = qr/[^>]*?/;
my $attribValueP = qr/[^"]*?/;		#" added for display only
my $numberP = qr/[\d\.]+/;
#=============================================================
#  GLOBALS
#=============================================================

#=============================================================
#  MAIN
#=============================================================
umask 000;
#basic checks
badExit("This is an XPP transformation tool") unless (scalar(@ARGV) == 2);
my $fileIn = shift;
my $fileOut = shift;
badExit("can not read inputfile\nlooking for: $fileIn") unless (-r $fileIn);
#ready to run
messageStart();
my $in = path($fileIn);
my $out = path($fileOut);
#run
my $content = $in->slurp_utf8;
$content = transform($content);
$out->spew_utf8($content);
#done
messageEnd();

exit(0);

#=============================================================
#  SUBS
#=============================================================
#-------------------------------------------------------------
sub badExit {
#-------------------------------------------------------------
	my $mesg = shift;
	my $sepError = "*" x 50; 						#sep for errormessages
	message("$sepError\nERROR:\n\t$mesg\n\tprogram stops\n$sepError\n", 0);
	#this is the end (on a bad note)
	exit(-1);		
}
#-------------------------------------------------------------
sub message {
#-------------------------------------------------------------
	my $mesg = shift;
	say $mesg;
	return();
}
#-------------------------------------------------------------
sub messageEnd {
#-------------------------------------------------------------
	my $SEP = "=" x 50;								#big separator for messages
	my $sep = "-" x 50;								#small separator for messages
	message("$sep\nDone\n$SEP");
}

#-------------------------------------------------------------
sub messageStart {
#-------------------------------------------------------------
	my $prog = basename($0);
	my $SEP = "=" x 50;								#big separator for messages
	my $sep = "-" x 50;								#small separator for messages
	$prog =~ s/\..*$//;
	message("$SEP\n$prog V: $Version\n$sep");
	return();
}	
#-------------------------------------------------------------
sub transform {
#-------------------------------------------------------------
	my $content = shift;
	my $page;
	message(">Transforming");
	#insert page numbers
	while ($content =~ s#<\?xpp MAIN;\d+;\d+;\d+;\d+;(\d+);\d;\d\?>##) {
		$page = $1;
		$content =~ s#<\?xpp /MAIN\?>\s+#<page nr="$page"/>#;
	}
	#strip start/end root tag
	$content =~ s#^<$tagP>\s*##s;
	$content =~ s#<$tagP>(<page $tagP/>)\s*$#$1\n#s;
	
	
	return($content);
}
